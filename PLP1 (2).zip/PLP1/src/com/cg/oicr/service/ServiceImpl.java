package com.cg.oicr.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.oicr.bean.Claim;
import com.cg.oicr.bean.PolicyDetails;
import com.cg.oicr.bean.Users;
import com.cg.oicr.dao.DaoImpl;
import com.cg.oicr.dao.IDao;
import com.cg.oicr.exception.InsuranceException;

public class ServiceImpl implements IService {
	IDao d=new DaoImpl();

	@Override
	public String Login(String username,String password) throws SQLException, IOException, InsuranceException {
		
		return d.Login( username, password);
		
		}
	
		public static boolean valiadate(Claim claim,PolicyDetails policy){
				boolean val=true;
			List<String> validationErrors = new ArrayList<String>();
			System.out.println(claim.getAccident_State());
			if(!(isValidClaimReason(claim.getClaim_Reason())))
			{
				validationErrors.add("\n Claim Reason should be in alphabets and min 5 characters long");
			}
			
			if(!(isValidAccidentLocation(claim.getAccident_Location_Street())))
			{
				validationErrors.add("\n Accident Location should be greater than 5 char \n");
			}
			if(!(isValidAccidentCity(claim.getAccident_City())))
			{
				validationErrors.add("\n Accident City should be in alphabets and min 5 characters long");
			}
			if(!(isValidAccidentState(claim.getAccident_State())))
			{
				validationErrors.add("\n Accident State should be in alphabets and min 5 characters long");
			}
			if(!(isValidAccidentZip(claim.getAccident_Zip())))
			{
				validationErrors.add("\n AccidentZip must be 5digit\n");
			}
			
			if(!(isValidPolicyNumber(policy.getPolicy_Number())))
			{
				validationErrors.add("\n Policy Number should be positive number \n");
			}
			
			
			if(!validationErrors.isEmpty()){
				System.err.println(validationErrors);
				val=false;				
			}else{
				val=true;
			}
			
			return val;
		}
		
		public boolean validatepassword(Users user) {
			
			Pattern p=Pattern.compile("^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$");
			Matcher m=p.matcher(user.getPassword());
			return m.matches();
			
		}
		private static boolean isValidPolicyNumber(long policyNumber) {
			String s=String.valueOf(policyNumber);
			Pattern p=Pattern.compile("[0-9]{10}");
			Matcher m=p.matcher(s);
			return m.matches();
			}

		
		
		private static boolean isValidAccidentZip(int accidentZip) {
			String s=String.valueOf(accidentZip);
			Pattern p=Pattern.compile("[4-7][0-9]{5}");
			Matcher m=p.matcher(s);
			return m.matches();
		}

		private static boolean isValidAccidentState(String accidentState) {
			
			Pattern p=Pattern.compile("[A-Z][A-Za-z /W ]{3,10}");
			Matcher m=p.matcher(accidentState);
			return m.matches();
			}

		private static boolean isValidAccidentCity(String accidentCity) {
			Pattern p=Pattern.compile("[A-Z][A-Za-z]{3,10}");
			Matcher m=p.matcher(accidentCity);
			return m.matches();
	}

		private static boolean isValidAccidentLocation(String accidentLocation) {
			Pattern p=Pattern.compile("[A-Z][A-Za-z]{3,10}");
			Matcher m=p.matcher(accidentLocation);
			return m.matches();
	}

		private static boolean isValidClaimReason(String claimReason) {
			Pattern p=Pattern.compile("[A-Z][A-Za-z]{3,10}");
			Matcher m=p.matcher(claimReason);
			return m.matches();
	}

		@Override
		public List questions(int a) throws ClassNotFoundException, IOException {
			List li=new ArrayList();
					
			li=d.questions(a);
			
			
			return li;
		}

		@Override
		public int insert(long q,int b,String id) throws SQLException, IOException {
			int count=d.insert(q, b, id);
			return count;
		}

		@Override
		public String addHisCustomer(String user, String agent) throws IOException, SQLException {
			
			return d.addHisCustomer(user, agent); 
		}

		@Override
		public long createClaim(Claim claim, PolicyDetails policy) throws IOException, SQLException {
			
			return d.createClaim(claim, policy);
		}

		@Override
		public List getPolicyDetails(String name) throws Exception {
			
			return d.getPolicyDetails(name);
		}

		@Override
		public boolean addDetails(Users user) throws ClassNotFoundException, SQLException, Exception {
			
	
			return d.addDetails(user);
		}

		@Override
		public List viewClaim(long claimNo) throws ClassNotFoundException, SQLException, Exception {

			return d.viewClaim(claimNo);
		}

		@Override
		public boolean checkUser(String user) throws ClassNotFoundException, IOException, SQLException {

			return d.checkUser(user);
		}
		
		

}
