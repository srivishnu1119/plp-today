package com.cg.oicr.bean;

public class Users {
	private String Username;
	private String password;
	private String rollcode;
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRollcode() {
		return rollcode;
	}
	public void setRollcode(String rollcode) {
		this.rollcode = rollcode;
	}
	
}
