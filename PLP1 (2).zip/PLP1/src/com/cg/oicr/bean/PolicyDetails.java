package com.cg.oicr.bean;

public class PolicyDetails {
	private long policy_Number;
	private double policy_Premium;
	private String answer;
	private long account_number;
	public long getAccount_number() {
		return account_number;
	}
	public void setAccount_number(long account_number) {
		this.account_number = account_number;
	}
	public long getPolicy_Number() {
		return policy_Number;
	}
	public void setPolicy_Number(long policy_Number) {
		this.policy_Number = policy_Number;
	}
	public double getPolicy_Premium() {
		return policy_Premium;
	}
	public void setPolicy_Premium(double policy_Premium) {
		this.policy_Premium = policy_Premium;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}

}
