package com.cg.oicr.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.oicr.bean.Claim;
import com.cg.oicr.bean.PolicyDetails;
import com.cg.oicr.bean.Question;
import com.cg.oicr.bean.Users;
import com.cg.oicr.service.IService;
import com.cg.oicr.service.ServiceImpl;

public class InsuranceClaimMain {
	static int key;
	
	public static void main(String[] args) throws SQLException, IOException, ClassNotFoundException,Exception {
		PolicyDetails policy=new PolicyDetails();
		Scanner scan = new Scanner(System.in);
		System.out.println("_____________$ Insurance Claim Page $________________");
		
		System.out.println("*********User Login************");
		System.out.println("_______________________________");
		
		Users user=new Users();
		System.out.println("Username :");
		String username = scan.next();
		user.setUsername(username);
		System.out.println("Password :");
		String password= scan.next();
		ServiceImpl service=new ServiceImpl();
		
		String rolecode=service.Login(username,password);
		if(rolecode==null) {
			System.out.println("Enter valid credentials");
		}else {
			
		switch (rolecode) {
		
		case "USER000":
			
			System.out.println("**********INSURENCED PORTAL**********");
			System.out.println("\t1. Claim Creation");
			System.out.println("\t2. View Claim ");
			System.out.println("Enter your option");
			key = scan.nextInt();
			switch (key) {
			
			case 1:
				int a=dispPolicy(user.getUsername());
				if(a!=0) {
				claim();
				}
				break;
			case 2:
				System.out.println("Claim Number");
				long claimNo=scan.nextLong();
				List list=new ArrayList();
				list=service.viewClaim(claimNo);
				System.out.print("Claim Number :"+list.get(0)+"\t");
				System.out.print("\t Policy Number :"+list.get(1)+"\t");
				System.out.print("\t Claim Type :"+list.get(2)+"\t");
				break;
			
			default:
				System.out.println("Enter Value Between 1-2");
				break;
			}

			break;
		
		case "AGENT000":
			while(true){		
			System.out.println("**********AGENT PORTAL**********");
			System.out.println("\t1. Claim Creation");
			System.out.println("\t2. View Claim ");
			System.out.println("\t3. Add your customer");
			System.out.println("\t4. Exit");
			System.out.println("Enter your option");
			key = scan.nextInt();
			switch (key) {
			case 1:
				
				System.out.println("Enter Insured Id to create Claim");
				String user3=scan.next();
				boolean dumm=service.checkUser(user3);
				if(dumm==true){
						
				int a=dispPolicy(user3);
				if(a!=0) {
				claim();
				}
				else{
					System.out.println("No policies");
					}
				}
				else{
					System.out.println("He is not your Customer...!!");
				}
				break;
			case 2:
				System.out.println("Claim Number");
				long claimNo=scan.nextLong();
				List list=new ArrayList();
				list=service.viewClaim(claimNo);
				System.out.print("Claim Number :"+list.get(0)+"\t");
				System.out.print("\t Policy Number :"+list.get(1)+"\t");
				System.out.print("\t Claim Type :"+list.get(2)+"\t");
				break;

						
			case 3:
				InsuranceClaimMain icm=new InsuranceClaimMain();
				System.out.println("Enter UserId");
				String user1=scan.next();
				System.out.println(user.getUsername());
				String ack=service.addHisCustomer(user1,user.getUsername());
				if(ack!=null)
				{
					System.out.println(ack);
				}
				else
				{
					System.out.println("enter valid existing user");
					
				}
				break;
			case 4:
				System.exit(0);
				break;
			default:
				System.out.println("Enter Value Between 1-3");
				break;
			}
		
			}
			
		case "ADMIN000":
			while(true) {
			System.out.println("**********ADMIN PORTAL**********");
			System.out.println("\t1. New Profile Creation");
			System.out.println("\t2. Claim Creation");
			System.out.println("\t3. View Claim ");
			System.out.println("\t4. New Report Generation");
			System.out.println("Enter your option");
			key = scan.nextInt();
			switch (key) {
			case 1:
				System.out.println("*** PROFILE CREATION *** ");
				System.out.println("USERNAME:");
				user.setUsername(scan.next());
				System.out.println("PASSWORD:");
				user.setPassword(scan.next());
				System.out.println("ROLE CODE:");
				user.setRollcode(scan.next());
								
					boolean ack=service.validatepassword(user);
					if(ack==true) {
		     	boolean ack1=service.addDetails(user);
				if(ack1==true){
				System.out.println("profile has been succesfully created");
				}else
				{
					System.out.println("User name exisiting try again");
				}
					}
					else {
						System.out.println("enter valid password which should be At least 8 chars\r\n" + 
								"\r\n" + 
								"Contains at least one digit\r\n" + 
								"\r\n" + 
								"Contains at least one lower alpha char and one upper alpha char\r\n" + 
								"\r\n" + 
								"Contains at least one char within a set of special chars (@#%$^ etc.)\r\n" + 
								"\r\n" + 
								"Does not contain space, tab, etc.");
						System.out.println("PASSWORD:");
						user.setPassword(scan.next());
						service.validatepassword(user);
						
						System.out.println("profile has been succesfully created");
					}
				break;
				
			case 2:
				System.out.println("Enter Insured Id");
				String user1=scan.next();
				int a=dispPolicy(user1);
				if(a!=0) {
				claim();
				}
				break;
				
			case 3:
				System.out.println("Claim Number");
				long claimNo=scan.nextLong();
				List list=new ArrayList();
				list=service.viewClaim(claimNo);
				System.out.print("Claim Number :"+list.get(0)+"\t");
				System.out.print("\t Policy Number :"+list.get(1)+"\t");
				System.out.print("\t Claim Type :"+list.get(2)+"\t");
				break;
				
			case 4:
				
				break;
			
			default:
				System.out.println("Enter Value Between 1-4");
				break;
			}
			}
		default:
			System.out.println("Enter Value Between 1-4");
			break;
		}	
		}
			}
		
		

	public static void claim() throws SQLException, ClassNotFoundException, IOException{
		Claim claim=new Claim();
		PolicyDetails policy=new PolicyDetails();
		ServiceImpl iS=new ServiceImpl();
		
		Scanner scan=new Scanner(System.in);
				
		System.out.println("Claim Reason");
		String str=scan.nextLine();
		claim.setClaim_Reason(str);
		
		System.out.println("Accident Location");
		String str1=scan.nextLine();
		claim.setAccident_Location_Street(str1);
		
		System.out.println("Accident City");
		String str2=scan.nextLine();
		claim.setAccident_City(str2);
		
		System.out.println("Accident State");
		String state=scan.nextLine();
		claim.setAccident_State(state);
		
		System.out.println("Accident Zip");
		int str3=scan.nextInt();
		claim.setAccident_Zip(str3);
		
		System.out.println("Policy Number");
		long str5=scan.nextLong();
		policy.setPolicy_Number(str5);
		
		System.out.println("Enter Claim Type :");
		System.out.println("1.earthquake");
		System.out.println("2.cyclone");
		System.out.println("3.fire");
		System.out.println("4.accident");
		System.out.println("5.theft");
		
		System.out.println("Claim Type");
		int str4=scan.nextInt();
		claim.setClaim_Type(str4);
		
		boolean b=iS.valiadate(claim,policy);
		
		if(b==true)
		{
			if(str4==1)
			{
				claim.setClaim_Type1("earthquake");
			}
			else if(str4==2){
				claim.setClaim_Type1("cyclone");
			}else if(str4==3){
				claim.setClaim_Type1("fire");
			}else if(str4==4){
				claim.setClaim_Type1("accident");
			}else
			{				
					claim.setClaim_Type1("theft");
			}
			
			Question question=new Question();
			
			int i=0;
			int count=0;
			
			
			List<String> li=new ArrayList<String>();
			
			li=iS.questions(claim.getClaim_Type());
			
			Iterator<String> itr= li.iterator();
			
			
			while(itr.hasNext()) {
				if(i%2!=0) {
				System.out.println(li.get(i));
				System.out.println("1.yes   2.no");
				
					int c=scan.nextInt();
					question.setQuestion_Name(li.get(i));
					count+=iS.insert(policy.getPolicy_Number(),c,question.getQuestion_Id());						
					
				}
				else
				{
					question.setQuestion_Id(li.get(i));
				}
					if(i>=9)
					{
						break;
					}	
			
					i++; 
			}
			
			if(count>2){
				long claimNo=iS.createClaim(claim, policy);
				System.out.println("!!..MAKE A NOTE OF THIS..!!");
				System.out.println("Your claim number is : "+claimNo);
							
			}
			else {
				System.out.println("not eligible for claim");
			}
		}
		else
		{
			System.out.println("Enter Again!!!!!!");
			claim();
		}
	}	
	
	private static int dispPolicy(String name) throws Exception {
		PolicyDetails policy=new PolicyDetails();
		List<PolicyDetails> p=new ArrayList();
		ServiceImpl iS=new ServiceImpl();
		int a=0;
		p=iS.getPolicyDetails(name);
		if (!p.isEmpty()) {
			for(PolicyDetails l:p)
			{
				System.out.print("AccountNumber \t"+l.getAccount_number());
				System.out.print("\t Premium "+l.getPolicy_Premium());
				System.out.print("Policy Number"+l.getPolicy_Number()+"\n");
			}
			a=23;
		} 
		else
		  {
			System.out.println("NO policy details under this name, yet.");
		   }
		
		return a;
		}
	
	
}