package com.cg.oicr.dao;



import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;





import com.cg.oicr.bean.Claim;
import com.cg.oicr.bean.PolicyDetails;
import com.cg.oicr.bean.Users;
import com.cg.oicr.exception.InsuranceException;
import com.cg.oicr.util.DBconnection;

public class DaoImpl implements IDao {
	
	
	
	
	

	@Override
	public String Login(String username, String password) throws SQLException, IOException, InsuranceException {
		String uname=null;
		String pwd=null;
		String rolecode=null;
		DBconnection db=new DBconnection();
		Connection connection=db.getConnection();
		Statement stm=connection.createStatement();
		ResultSet rs=stm.executeQuery(" select username,password from user_role");
		while(rs.next()){
			uname=rs.getString(1);
			pwd=rs.getString(2);
			if(username.equals(uname)&&password.equals(pwd)){
				uname=username;
				pwd=password;
				break;
			}
			uname=null;
			pwd=null;
		}
		
		PreparedStatement pst=connection.prepareStatement("select rolecode from user_role where username=? and password=?");
		pst.setString(1,uname);
		pst.setString(2,pwd);
		
		ResultSet rs1=pst.executeQuery();
		while(rs1.next()) {
			
			rolecode=rs1.getString(1);
			
			
		}
		
		if(rs1==null)
		{
//			logger.error("login failed ");
			throw new InsuranceException("login again ");

		}
		else
		{
			
//			logger.info("login done successfully:");
			
			return rolecode;
		}
		//return rolecode;
	}

	

	@Override
	public List questions(int a) throws ClassNotFoundException, IOException {
		
		List li=new ArrayList();
		DBconnection db=new DBconnection();
		Connection connection=db.getConnection();
		PreparedStatement pS=null;
		ResultSet rs=null;
			try {
						
				switch(a) {
				case 1:
								
					pS=connection.prepareStatement("select questionid,question from question where questionid between '1.1' and '1.5'");
					rs=pS.executeQuery();
					while(rs.next())
					{
						li.add(rs.getString(1));
						li.add(rs.getString(2));
					}
					break;
					
				case 2:	
					pS=connection.prepareStatement("select questionid,question from question where questionid between '2.1' and '2.5'");
					 rs=pS.executeQuery();
					while(rs.next())
					{
						li.add(rs.getString(1));
						li.add(rs.getString(2));
					}
					break;
				case 3:
					
					 pS=connection.prepareStatement("select questionid,question from question where questionid between '3.1' and '3.5'");
					 rs=pS.executeQuery();
					while(rs.next())
					{
						li.add(rs.getString(1));
						li.add(rs.getString(2));
					}
					break;
					
				case 4:
					 pS=connection.prepareStatement("select questionid,question from question where questionid between '4.1' and '4.5'");
					 rs=pS.executeQuery();
					while(rs.next())
					{
						li.add(rs.getString(1));
						li.add(rs.getString(2));
					}
					break;
					
				case 5:
					 pS=connection.prepareStatement("select questionid,question from question where questionid between '5.1' and '5.5'");
					 rs=pS.executeQuery();
					while(rs.next())
					{
						li.add(rs.getString(1));
						li.add(rs.getString(2));
					}
					break;
				}	
			
			
				connection.close();
				rs=null;
				pS=null;
		}catch(SQLException e){
			e.printStackTrace();
			}
						
			return li;
	
	}

	@Override
	public int insert(long q, int b, String id) throws SQLException, IOException {
		String answer=null;
		int count=0;
		
		switch(b)
		{
		case 1:
			answer="yes";
			count+=1;
			break;
		case 2:
			answer="no";
			break;
		}
		try {
		DBconnection db=new DBconnection();
		Connection connection=db.getConnection();	
		PreparedStatement ps1=connection.prepareStatement("insert into policy_details values(?,?,?)");
		ps1.setLong(1,q);
		ps1.setString(2,id);
		ps1.setString(3,answer);
		ps1.executeUpdate();
		
		connection.close();
		ps1.close();
				
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return count;
	}

	@Override
	public String addHisCustomer(String user, String agent) throws IOException, SQLException {
		DBconnection db=new DBconnection();
		Connection connection=db.getConnection();
		String user1=user;
		String user2=null;
		String ack=null;
		Statement statement=connection.createStatement();
		ResultSet rs=statement.executeQuery("select username from user_role");
		while(rs.next())
		{
			user2=rs.getString(1);
			if(user2.equals(user1)){
				
					PreparedStatement pS=connection.prepareStatement("insert into agent values(?,?)");
					pS.setString(1,user1);
					pS.setString(2,agent);
					pS.executeUpdate();
					ack="Values inserted";
					break;
				
			}
			
		}
		
		return ack;
	}

	@Override
	public List getPolicyDetails(String name) throws Exception {
		PreparedStatement ps=null;
		ResultSet rs=null;
		List p=new ArrayList();
		String name1=null;
		ResultSet rs1=null;
		PolicyDetails policy=null;
		try {
		Connection con=DBconnection.getConnection();
		String name2=name;
		
		ps=con.prepareStatement("select username from user_role");
		
		rs=ps.executeQuery();
		while(rs.next())
			{
				 name1=rs.getString(1);
				 if(name1.equals(name2))
				 {
			        ps=con.prepareStatement("select * from policy1 where accountnumber in (select accountnumber from account1 where username=?)");	
		            ps.setString(1,name2);
		            rs1=ps.executeQuery();
			        break;
				 }
		       name1=null;
		    }
					
		while(rs1.next())
		{
			
			policy=new PolicyDetails();
			policy.setPolicy_Number(rs1.getLong(1));	
			policy.setPolicy_Premium(rs1.getFloat(2));
			policy.setAccount_number(rs1.getLong(3));
			p.add(policy);		
		}
		
		con.close();
		ps.close();
		rs.close();
		
		}
		catch(Exception e)
		{
			System.out.println(e);
			e.printStackTrace();
		}

		 return p;
			
	}

	@Override
	public long createClaim(Claim claim, PolicyDetails policy) throws IOException, SQLException {
		long claimNo=0;
		
		try {
		DBconnection db=new DBconnection();
		Connection connection=db.getConnection();
		
		PreparedStatement pS=connection.prepareStatement("insert into claim values(claim_number.nextval,?,?,?,?,?,?,?)");
		pS.setString(1,claim.getClaim_Reason());
		pS.setString(2,claim.getAccident_Location_Street());
		pS.setString(3,claim.getAccident_City());
		pS.setString(4, claim.getAccident_State());
		pS.setInt(5, claim.getAccident_Zip());
		pS.setString(6, claim.getClaim_Type1());
		pS.setLong(7,policy.getPolicy_Number());
		pS.executeUpdate();
		
		Statement s=connection.createStatement();
		ResultSet rs=s.executeQuery("select claim_number.currval from claim");
		while(rs.next())
		{
			 claimNo=rs.getLong(1);
		}
					
		rs=null;
		connection.close();
		pS.close();
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return claimNo;
	}

	@Override
	public boolean addDetails(Users user) throws ClassNotFoundException, SQLException, Exception {
		
		boolean boo=true;
		Connection connection = DBconnection.getConnection();	
		String dumm=user.getUsername();
		PreparedStatement preparedStatement=null;			
		
		try
		{	
			String username=null;
			preparedStatement=connection.prepareStatement("select username from user_role");
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()) {
				username=resultSet.getString(1);
				if(dumm.equals(username))
				{
					username=dumm;
					break;
				}
				
			}
			if(!user.getUsername().equals(username)){
			preparedStatement=connection.prepareStatement("INSERT INTO user_role VALUES(?,?,?)");
            preparedStatement.setString(1,username);			
			preparedStatement.setString(2,user.getPassword());
			preparedStatement.setString(3,user.getRollcode());
			preparedStatement.executeUpdate();
			}
			else
			{
				boo=false;
				connection.close();
				preparedStatement.close();
				resultSet.close();
			}
	}catch(Exception e) {
		e.printStackTrace();
		
	}
		return boo;				
}
	

	@Override
	public List viewClaim(long claimNo) throws ClassNotFoundException, SQLException, Exception {
		Connection connection=DBconnection.getConnection();
		PreparedStatement st=null;
		 List list=new ArrayList();
		long a=claimNo;
		
		try
		{      
			
		st=connection.prepareStatement("select claimnumber,policynumber,claimtype from claim where claimnumber=?");
		st.setLong(1, a);
		ResultSet resultSet = st.executeQuery();
				
			while(resultSet.next())
			{		
				
			list.add(resultSet.getLong(1));
			list.add(resultSet.getLong(2));
			list.add(resultSet.getString(3));
			}
			connection.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}



	@Override
	public boolean checkUser(String user) throws IOException,SQLException,ClassNotFoundException {
		Connection connection=DBconnection.getConnection();
		PreparedStatement st=null;
		String user1=null;
		boolean boo=false;
		st=connection.prepareStatement("select userid from agent where agentid=?");
		st.setString(1,user);
		ResultSet rs=st.executeQuery();
		while(rs.next())
		{
			System.out.println("eneterd");
			user1=rs.getString(1);
			if(user1.equals(user)){
				user1=user;
				boo=false;
				break;
			}
			user1=null;
		}
		
		
		return boo;
	}

}
