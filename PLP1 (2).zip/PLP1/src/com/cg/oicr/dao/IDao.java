package com.cg.oicr.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.oicr.bean.Claim;
import com.cg.oicr.bean.PolicyDetails;
import com.cg.oicr.bean.Users;
import com.cg.oicr.exception.InsuranceException;

public interface IDao {
	public String Login(String username,String password) throws SQLException, IOException, InsuranceException;
	

	
	List questions(int a) throws ClassNotFoundException, IOException;
	
	int insert(long q,int b,String id) throws SQLException, IOException;
	
	String addHisCustomer(String user,String agent) throws IOException, SQLException;
	
	List getPolicyDetails(String name) throws Exception;
	
	long createClaim(Claim claim,PolicyDetails policy) throws IOException, SQLException;
	
	public boolean addDetails(Users user) throws ClassNotFoundException, SQLException, Exception;
	
	public List viewClaim(long claimNo) throws ClassNotFoundException, SQLException, Exception;
	
	boolean checkUser(String user) throws IOException, SQLException, ClassNotFoundException;
}
